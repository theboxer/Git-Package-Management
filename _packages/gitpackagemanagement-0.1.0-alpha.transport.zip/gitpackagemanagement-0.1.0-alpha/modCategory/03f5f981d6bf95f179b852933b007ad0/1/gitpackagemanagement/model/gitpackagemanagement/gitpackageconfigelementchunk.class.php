<?php

class GitPackageConfigElementChunk extends GitPackageConfigElement{
    protected $type = 'chunk';
}