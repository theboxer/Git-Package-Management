<?php

class GitPackageConfigElementSnippet extends GitPackageConfigElement{
    protected $type = 'snippet';
}