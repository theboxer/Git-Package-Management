<?php

class GitPackageConfigElementTemplate extends GitPackageConfigElement{
    protected $type = 'template';
}