--------------------
GitPackageManagement
--------------------
Version: 0.1.2 alpha
Author: Jan Peca <pecajan@gmail.com>
--------------------

Manage downloaded packages or clone and install package directly from git.

After installation please set git_path in system settings to your git executable.