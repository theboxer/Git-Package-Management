<?php

class GitPackageConfigElementChunk extends GitPackageConfigElement{
    protected $type = 'chunk';
    protected $extension = 'tpl';
}