# Intro

Git Package Management [GPM] is a component for MODX Revolution.

The main purpose is to make life easier for MODX developers. After installation you can manage components that are stored [outside of MODX root directory](http://rtfm.modx.com/revolution/2.x/case-studies-and-tutorials/developing-an-extra-in-modx-revolution).

After creating straightforward json config, you can install the component to the MODX and continue in development process. You will never again need to manually create system settings, menus, elements and database tables.
