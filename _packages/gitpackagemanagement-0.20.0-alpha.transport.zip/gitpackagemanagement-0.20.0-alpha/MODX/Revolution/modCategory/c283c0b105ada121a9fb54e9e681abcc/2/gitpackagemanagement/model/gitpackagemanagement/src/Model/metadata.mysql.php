<?php
$xpdo_meta_map = array (
    'xPDO\\Om\\xPDOSimpleObject' => 
    array (
        0 => 'GitPackageManagement\\Model\\GitPackage',
    ),
);