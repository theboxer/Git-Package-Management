<?php
namespace GitPackageManagement\Config;

class ElementChunk extends Element{
    protected $type = 'chunk';
    protected $extension = 'tpl';
}
