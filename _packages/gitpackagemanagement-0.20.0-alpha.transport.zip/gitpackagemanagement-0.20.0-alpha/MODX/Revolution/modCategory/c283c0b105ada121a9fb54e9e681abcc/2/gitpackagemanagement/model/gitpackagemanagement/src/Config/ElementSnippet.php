<?php
namespace GitPackageManagement\Config;

class ElementSnippet extends Element{
    protected $type = 'snippet';
    protected $extension = 'php';
}
