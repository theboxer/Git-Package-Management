<?php return array (
  'test resource' => 21,
);